GRANT  SELECT  ON [DBO].[Company]  TO [wswebuser]
GO
GRANT  SELECT  ON [DBO].[User2]  TO [wswebuser]
GO
GRANT  SELECT  ON [DBO].[Batch]  TO [wswebuser]
GO
GRANT  SELECT   ON [dbo].[Batch_Record]  TO [wswebuser]
GO  
GRANT  SELECT   ON [dbo].[Record_Case]  TO [wswebuser]
GO  
GRANT  SELECT   ON [dbo].[Case_Type]  TO [wswebuser]
GO  
GRANT  SELECT   ON [dbo].[Record_Status_Type]  TO [wswebuser]
GO  
GRANT  SELECT   ON [dbo].[Action_Type]  TO [wswebuser]
GO  


IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('ActualCaseType') AND TABLE_NAME IN ('Batch_Record'))
	ALTER TABLE DBO.[Batch_Record] ADD ActualCaseType varchar(200) NULL
GO

IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('DistrictCourt') AND TABLE_NAME IN ('Record_Case'))
	ALTER TABLE DBO.[Record_Case] ADD DistrictCourt varchar(200) NULL
GO

IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('CaseTypeLevel') AND TABLE_NAME IN ('Record_Case'))
	ALTER TABLE DBO.[Record_Case] ADD CaseTypeLevel varchar(200) NULL
GO

IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('CaseName') AND TABLE_NAME IN ('Record_Case'))
	ALTER TABLE DBO.[Record_Case] ADD CaseName varchar(200) NULL
GO

IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('Plaintiff') AND TABLE_NAME IN ('Record_Case'))
	ALTER TABLE DBO.[Record_Case] ADD Plaintiff varchar(200) NULL
GO

IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('Defendant') AND TABLE_NAME IN ('Record_Case'))
	ALTER TABLE DBO.[Record_Case] ADD Defendant varchar(200) NULL
GO

 IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('StatusJudgment') AND TABLE_NAME IN ('Record_Case'))
	ALTER TABLE DBO.[Record_Case] ADD StatusJudgment varchar(200) NULL
GO

 IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('IsCivil') AND TABLE_NAME IN ('Case_Type'))
	ALTER TABLE DBO.[Case_Type] ADD IsCivil BIT
GO
