GRANT  SELECT  ON [DBO].[Company]  TO [wswebuser]
GO
GRANT  SELECT  ON [DBO].[User2]  TO [wswebuser]
GO
GRANT  SELECT  ON [DBO].[Batch]  TO [wswebuser]
GO
GRANT  SELECT   ON [dbo].[Batch_Record]  TO [wswebuser]
GO  
GRANT  SELECT   ON [dbo].[Record_Case]  TO [wswebuser]
GO  
GRANT  SELECT   ON [dbo].[Case_Type]  TO [wswebuser]
GO  
GRANT  SELECT   ON [dbo].[Record_Status_Type]  TO [wswebuser]
GO  
GRANT  SELECT   ON [dbo].[Action_Type]  TO [wswebuser]
GO  


IF NOT EXISTS (SELECT 'X' FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME IN ('ActualCaseType') AND TABLE_NAME IN ('Batch_Record'))
	ALTER TABLE DBO.[Batch_Record] ADD ActualCaseType varchar(200) NULL
GO
